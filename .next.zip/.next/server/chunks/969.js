"use strict";
exports.id = 969;
exports.ids = [969];
exports.modules = {

/***/ 5969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   E: () => (/* binding */ useAuthContext),
/* harmony export */   Z: () => (/* binding */ AuthData)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4661);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5925);
/* harmony import */ var next_router_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_3__.createContext)();
function AuthData({ children  }) {
    const router = (0,next_router_js__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [isLogged, setIsLogged] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [signUpRes, setSignUpRes] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const [signInRes, setSignInRes] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (!localStorage.getItem("UserData")) {
            localStorage.setItem("UserData", []);
            setIsLogged(false);
        } else {
            setIsLogged(true);
            setSignInRes(JSON.parse(localStorage.getItem("UserData")));
        }
    }, []);
    const SignUp = async (values)=>{
        setIsLoading(true);
        setSignUpRes(null);
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("https://note-keep-6545.vercel.app/user/signup", values);
            setSignUpRes(data);
            setIsLoading(false);
        } catch (error) {
            setIsLoading(false);
        }
    };
    const SignIn = async (values)=>{
        setIsLoading(true);
        setSignInRes(null);
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("https://note-keep-6545.vercel.app/user/signin", values);
            setSignInRes(data);
            if (data && data.success) {
                setIsLogged(true);
                localStorage.setItem("UserData", JSON.stringify(data.user));
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_5___default().mixin({
                    toast: true,
                    position: "bottom-start",
                    showConfirmButton: false,
                    timer: 3000,
                    background: "black",
                    color: "white",
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_5___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_5___default().resumeTimer));
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: "Signed in successfully"
                });
                setTimeout(()=>{
                    router.push("/");
                }, 500);
            }
            setIsLoading(false);
        } catch (error) {
            setIsLoading(false);
            return error;
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: {
            SignUp,
            signUpRes,
            setSignUpRes,
            SignIn,
            isLogged,
            setIsLogged,
            signInRes,
            setSignInRes,
            isLoading
        },
        children: children
    });
}
function useAuthContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(AuthContext);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;