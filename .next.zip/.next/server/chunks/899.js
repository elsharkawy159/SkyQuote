"use strict";
exports.id = 899;
exports.ids = [899];
exports.modules = {

/***/ 9899:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ QuotesContext),
/* harmony export */   u: () => (/* binding */ useQuoteContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const QuoteContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)();
function QuotesContext({ children  }) {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [quoteRes, setQuoteRes] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [quotes, setQuotes] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const getAllQuotes = async (filter)=>{
        setIsLoading(true);
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`https://note-keep-6545.vercel.app/note?filter=${filter || "date-desc"}`);
            setQuotes(data);
            setIsLoading(false);
        } catch (error) {
            setQuoteRes(error);
            setIsLoading(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getAllQuotes();
        setQuoteRes("");
    }, []);
    const addQuote = async (values)=>{
        setIsLoading(true);
        setQuoteRes("");
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("https://note-keep-6545.vercel.app/note/add", values);
            setQuoteRes(data);
            if (data && data.success) {
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().mixin({
                    toast: true,
                    position: "bottom-start",
                    showConfirmButton: false,
                    timer: 3000,
                    background: "black",
                    color: "white",
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().resumeTimer));
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: data.message
                });
                getAllQuotes();
            }
            setIsLoading(false);
        } catch (error) {
            setQuoteRes(error);
            setIsLoading(false);
        }
    };
    const updateQuote = async (quoteId, values)=>{
        setIsLoading(true);
        setQuoteRes("");
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].put(`https://note-keep-6545.vercel.app/note/${quoteId}`, values);
            setQuoteRes(data);
            setIsLoading(false);
            if (data && data.success) {
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().mixin({
                    toast: true,
                    position: "bottom-start",
                    showConfirmButton: false,
                    timer: 3000,
                    background: "black",
                    color: "white",
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().resumeTimer));
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: data.message
                });
                getAllQuotes();
            }
        } catch (error) {
            setQuoteRes(error);
            setQuoteRes(error);
        }
    };
    const deleteQuote = async (userId, quoteId)=>{
        setQuoteRes("");
        setIsLoading(true);
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"]["delete"](`https://note-keep-6545.vercel.app/note/${quoteId}`, {
                data: {
                    userId: userId
                }
            });
            setIsLoading(false);
            if (data) {
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().mixin({
                    toast: true,
                    position: "bottom-start",
                    showConfirmButton: false,
                    timer: 3000,
                    background: "black",
                    color: "white",
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_3___default().resumeTimer));
                    }
                });
                if (data.success) {
                    Toast.fire({
                        icon: "success",
                        title: data.message
                    });
                } else {
                    Toast.fire({
                        icon: "warning",
                        title: data.message
                    });
                }
                getAllQuotes();
            }
        } catch (error) {
            setQuoteRes(error);
            setIsLoading(false);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuoteContext.Provider, {
        value: {
            quotes,
            isLoading,
            getAllQuotes,
            addQuote,
            updateQuote,
            deleteQuote,
            quoteRes,
            setQuoteRes
        },
        children: children
    });
}
function useQuoteContext() {
    return (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(QuoteContext);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;