exports.id = 378;
exports.ids = [378];
exports.modules = {

/***/ 5327:
/***/ ((module) => {

// Exports
module.exports = {
	"box": "QuoteCard_box__NGmbM",
	"quoteFont": "QuoteCard_quoteFont__FkEP1",
	"cardFooter": "QuoteCard_cardFooter__RP4n5",
	"fas": "QuoteCard_fas__jvHfV",
	"fa2": "QuoteCard_fa2__LQPgH",
	"edit": "QuoteCard_edit__euWbS",
	"delete": "QuoteCard_delete__8EA7f",
	"copy": "QuoteCard_copy__EBIzT",
	"text": "QuoteCard_text__wB1yW",
	"fa1": "QuoteCard_fa1__mzgc7"
};


/***/ }),

/***/ 9077:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ EditQuote)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8611);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9868);
/* harmony import */ var _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _InputWithValidation_InputWithValidation_jsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9717);
/* harmony import */ var _Context_quoteData_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9899);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_7__]);
_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function EditQuote({ quoteId , title , description  }) {
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const fullScreen = _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default()(theme.breakpoints.down("md"));
    const userID = JSON.parse(localStorage.getItem("UserData"))?._id;
    const { updateQuote , quoteRes , setQuoteRes , isLoading  } = (0,_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_7__/* .useQuoteContext */ .u)();
    const handleEditQuote = async (values, quoteId)=>{
        await updateQuote(quoteId, values);
        setTimeout(()=>{
            setQuoteRes("");
        }, 3000);
        handleClose();
    };
    const handleClickOpen = async ()=>{
        setOpen(true);
    };
    const handleClose = ()=>{
        setOpen(false);
    };
    let quoteSchema = (0,yup__WEBPACK_IMPORTED_MODULE_8__.object)({
        title: (0,yup__WEBPACK_IMPORTED_MODULE_8__.string)().required("Title is required").min(3, "Minimum Length is 3").max(20, "Maximum Length is 20"),
        description: (0,yup__WEBPACK_IMPORTED_MODULE_8__.string)().required("Description is required").matches(/^(?!.*([a-zA-Z])\1{3,}).*$/, "Description contains spam input").min(10, "Minimum Length is 10").max(93, "Maximum Length is 93")
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "fa-solid fa-pen",
                onClick: handleClickOpen
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2___default()), {
                fullScreen: fullScreen,
                open: open,
                onClose: handleClose,
                "aria-labelledby": "responsive-dialog-title",
                className: "container-fluid p-0 shadow",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "row m-0 bg-dark",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-md-12 col-sm-8 col-12 text-light shadow p-5 rounded-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "tab-content",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_5__.Formik, {
                                initialValues: {
                                    author: userID,
                                    title: title || "",
                                    description: description || ""
                                },
                                validationSchema: quoteSchema,
                                onSubmit: (values)=>{
                                    handleEditQuote(values, quoteId);
                                },
                                children: ({ values , errors , touched , handleChange , handleBlur , handleSubmit  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                        onSubmit: handleSubmit,
                                        className: "row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "title text-center mb-3",
                                                children: "EDIT QUOTE"
                                            }),
                                            quoteRes && (quoteRes.success ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-center bg-success rounded-3 bg-opacity-50 h6 p-1 mb-3",
                                                children: quoteRes.message
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "text-center bg-danger rounded-3 bg-opacity-50 h6 p-1 mb-3",
                                                children: quoteRes.message
                                            })),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputWithValidation_InputWithValidation_jsx__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                name: "title",
                                                label: "Quote Title",
                                                value: values.title,
                                                onChange: handleChange,
                                                onBlur: handleBlur,
                                                error: errors.title,
                                                touched: touched.title,
                                                maxlength: 20
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputWithValidation_InputWithValidation_jsx__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                name: "description",
                                                label: "Description",
                                                value: values.description,
                                                onChange: handleChange,
                                                onBlur: handleBlur,
                                                error: errors.description,
                                                touched: touched.description,
                                                maxlength: 93
                                            }),
                                            isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                disabled: true,
                                                className: "btn btn-outline-light fw-bolder fs-6 btn-block border-1 mb-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "fa-solid fa-spinner fa-spin"
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                className: "btn btn-outline-light fw-bolder fs-6 btn-block border-1 mb-4",
                                                children: "Save Changes"
                                            })
                                        ]
                                    })
                            })
                        })
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   d: () => (/* binding */ QuoteCardSkeleton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(441);
/* harmony import */ var _mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5327);
/* harmony import */ var _QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const QuoteCardSkeleton = ({ length , col  })=>{
    const skeletons = Array.from({
        length
    }).map((_, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `${col} ${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().box)} `,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: `${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fas)} fa-solid fa-quote-left ${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fa2)}`
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().text),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: `${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fas)} fa-solid fa-quote-right ${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fa1)}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: `${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fas)} fa-solid fa-copy ${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().fa1)} ${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().copy)}`,
                            title: "Copy"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "d-flex justify-content-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        animation: "wave",
                                        style: {
                                            width: "200px"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: `${(_QuoteCard_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_3___default().quoteFont)} overflow-auto text-light fs-5 mb-1`,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            animation: "wave"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            animation: "wave"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-auto h-100 d-flex align-content-end justify-content-between align-items-end flex-wrap",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "text-light m-0 mb-sm-4 d-flex",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "fw-semibold opacity-75",
                                            children: "Created By:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-light fw-medium pointer m-0 ms-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                animation: "wave",
                                                style: {
                                                    width: "100px"
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "text-light m-0 mb-sm-4 d-flex",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "fw-semibold opacity-75",
                                            children: "Date:"
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "m-0 ms-2",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Skeleton__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                animation: "wave",
                                                style: {
                                                    width: "100px"
                                                }
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        }, i));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: skeletons
    });
};


/***/ }),

/***/ 4378:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ QuoteCard),
/* harmony export */   V: () => (/* binding */ QuoteCardList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5327);
/* harmony import */ var _QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _Context_quoteData_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9899);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5384);
/* harmony import */ var next_link_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _EditQuote_EditQuote_jsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9077);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _QuoteCardSkeleton_QuoteCardSkeleton_jsx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2771);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_2__, _EditQuote_EditQuote_jsx__WEBPACK_IMPORTED_MODULE_5__]);
([_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_2__, _EditQuote_EditQuote_jsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const QuoteCard = ({ title , quote , by , at , col , quoteUID , quoteId  })=>{
    const [isOwner, setisOwner] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { deleteQuote , quoteRes  } = (0,_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_2__/* .useQuoteContext */ .u)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const userData = localStorage.getItem("UserData");
        if (userData) {
            const userDataObj = JSON.parse(userData);
            if (userDataObj._id) {
                const loggedUID = userDataObj._id;
                if (loggedUID == quoteUID) {
                    setisOwner(true);
                } else {
                    setisOwner(false);
                }
            }
        }
    }, []);
    const handleCopyClick = ()=>{
        navigator.clipboard.writeText(quote);
        const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().mixin({
            toast: true,
            position: "bottom-start",
            showConfirmButton: false,
            timer: 3000,
            background: "black",
            color: "white",
            timerProgressBar: true,
            didOpen: (toast)=>{
                toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().stopTimer));
                toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().resumeTimer));
            }
        });
        Toast.fire({
            icon: "success",
            title: "Quote Copied"
        });
    };
    const handleDeleteQuote = (quoteUID, quoteId)=>{
        sweetalert2__WEBPACK_IMPORTED_MODULE_6___default().fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then(async (result)=>{
            if (result.isConfirmed) {
                await deleteQuote(quoteUID, quoteId);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${col} ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().box)} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fas)} fa-solid fa-quote-left ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fa2)} ${!isOwner || "text-primary"}`
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().text),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fas)} fa-solid fa-quote-right ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fa1)} ${!isOwner || "text-primary"}`
                    }),
                    isOwner ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fas)} ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fa1)} ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().edit)}`,
                                title: "Edit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EditQuote_EditQuote_jsx__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    quoteId: quoteId,
                                    title: title,
                                    description: quote
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                onClick: ()=>handleDeleteQuote(quoteUID, quoteId),
                                className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fas)} fa-solid fa-trash ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fa1)} ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default()["delete"])}`,
                                title: "Delete"
                            })
                        ]
                    }) : null,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                        onClick: handleCopyClick,
                        className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fas)} fa-solid fa-copy ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().fa1)} ${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().copy)}`,
                        title: "Copy"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: `${(_QuoteCard_module_scss__WEBPACK_IMPORTED_MODULE_8___default().quoteFont)} overflow-auto text-light fs-5 mb-1`,
                                children: quote
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-auto h-100 d-flex align-content-end justify-content-between align-items-end flex-wrap",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "text-light m-0 mb-sm-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fw-semibold opacity-75",
                                        children: "Created By: "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link_js__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: `/profile/${quoteUID}`,
                                        className: "text-light fw-medium",
                                        children: by
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "text-light m-0 mb-sm-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "fw-semibold opacity-75",
                                        children: "Date:"
                                    }),
                                    " ",
                                    at
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
const QuoteCardList = ({ length , col  })=>{
    const { quotes , isLoading  } = (0,_Context_quoteData_js__WEBPACK_IMPORTED_MODULE_2__/* .useQuoteContext */ .u)();
    if (isLoading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "conteiner-fluid",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row justify-content-evenly gap-5 m-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuoteCardSkeleton_QuoteCardSkeleton_jsx__WEBPACK_IMPORTED_MODULE_7__/* .QuoteCardSkeleton */ .d, {
                    length: length || 10,
                    col: col
                })
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "conteiner-fluid",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "row justify-content-evenly gap-5 m-0",
            children: quotes?.quotes?.slice(0, length).map((quote)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuoteCard, {
                    quoteId: quote?._id,
                    quoteUID: quote.author?._id,
                    title: quote?.title,
                    quote: quote?.description,
                    by: quote?.author?.userName,
                    at: moment__WEBPACK_IMPORTED_MODULE_3___default()(quote?.createdAt).format("LL"),
                    col: col
                }, quote?._id))
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;