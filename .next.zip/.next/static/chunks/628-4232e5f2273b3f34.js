"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[628],{3628:function(t,e,a){a.d(e,{Z:function(){return $}});var r=a(3366),n=a(7462),i=a(7294),o=a(6010);a(7278);var s=a(8137);function l(){for(var t=arguments.length,e=Array(t),a=0;a<t;a++)e[a]=arguments[a];return(0,s.O)(e)}a(8417),a(8679);var h=function(){var t=l.apply(void 0,arguments),e="animation-"+t.name;return{name:e,styles:"@keyframes "+e+"{"+t.styles+"}",anim:1,toString:function(){return"_EMO_"+this.name+"_"+this.styles+"_EMO_"}}},d=a(4780),u=a(1796),m=a(2641),p=a(3616),c=a(1588),f=a(7621);function g(t){return(0,f.Z)("MuiSkeleton",t)}(0,c.Z)("MuiSkeleton",["root","text","rectangular","rounded","circular","pulse","wave","withChildren","fitContent","heightAuto"]);var v=a(5893);let b=["animation","className","component","height","style","variant","width"],w=t=>t,k,y,C,Z,_=t=>{let{classes:e,variant:a,animation:r,hasChildren:n,width:i,height:o}=t;return(0,d.Z)({root:["root",a,r,n&&"withChildren",n&&!i&&"fitContent",n&&!o&&"heightAuto"]},g,e)},R=h(k||(k=w`
  0% {
    opacity: 1;
  }

  50% {
    opacity: 0.4;
  }

  100% {
    opacity: 1;
  }
`)),S=h(y||(y=w`
  0% {
    transform: translateX(-100%);
  }

  50% {
    /* +0.5s of delay between each loop */
    transform: translateX(100%);
  }

  100% {
    transform: translateX(100%);
  }
`)),x=(0,m.ZP)("span",{name:"MuiSkeleton",slot:"Root",overridesResolver:(t,e)=>{let{ownerState:a}=t;return[e.root,e[a.variant],!1!==a.animation&&e[a.animation],a.hasChildren&&e.withChildren,a.hasChildren&&!a.width&&e.fitContent,a.hasChildren&&!a.height&&e.heightAuto]}})(({theme:t,ownerState:e})=>{let a=String(t.shape.borderRadius).match(/[\d.\-+]*\s*(.*)/)[1]||"px",r=parseFloat(t.shape.borderRadius);return(0,n.Z)({display:"block",backgroundColor:t.vars?t.vars.palette.Skeleton.bg:(0,u.Fq)(t.palette.text.primary,"light"===t.palette.mode?.11:.13),height:"1.2em"},"text"===e.variant&&{marginTop:0,marginBottom:0,height:"auto",transformOrigin:"0 55%",transform:"scale(1, 0.60)",borderRadius:`${r}${a}/${Math.round(r/.6*10)/10}${a}`,"&:empty:before":{content:'"\\00a0"'}},"circular"===e.variant&&{borderRadius:"50%"},"rounded"===e.variant&&{borderRadius:(t.vars||t).shape.borderRadius},e.hasChildren&&{"& > *":{visibility:"hidden"}},e.hasChildren&&!e.width&&{maxWidth:"fit-content"},e.hasChildren&&!e.height&&{height:"auto"})},({ownerState:t})=>"pulse"===t.animation&&l(C||(C=w`
      animation: ${0} 1.5s ease-in-out 0.5s infinite;
    `),R),({ownerState:t,theme:e})=>"wave"===t.animation&&l(Z||(Z=w`
      position: relative;
      overflow: hidden;

      /* Fix bug in Safari https://bugs.webkit.org/show_bug.cgi?id=68196 */
      -webkit-mask-image: -webkit-radial-gradient(white, black);

      &::after {
        animation: ${0} 1.6s linear 0.5s infinite;
        background: linear-gradient(
          90deg,
          transparent,
          ${0},
          transparent
        );
        content: '';
        position: absolute;
        transform: translateX(-100%); /* Avoid flash during server-side hydration */
        bottom: 0;
        left: 0;
        right: 0;
        top: 0;
      }
    `),S,(e.vars||e).palette.action.hover)),M=i.forwardRef(function(t,e){let a=(0,p.Z)({props:t,name:"MuiSkeleton"}),{animation:i="pulse",className:s,component:l="span",height:h,style:d,variant:u="text",width:m}=a,c=(0,r.Z)(a,b),f=(0,n.Z)({},a,{animation:i,component:l,variant:u,hasChildren:!!c.children}),g=_(f);return(0,v.jsx)(x,(0,n.Z)({as:l,ref:e,className:(0,o.Z)(g.root,s),ownerState:f},c,{style:(0,n.Z)({width:m,height:h},d)}))});var $=M}}]);